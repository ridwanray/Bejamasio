export const nodeMan =()=>{
    console.log('coming from utils...node man')
}
