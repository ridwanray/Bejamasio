export const GetAllProducts_REQUEST = "GetAllProducts_REQUEST";
export const GetAllProducts_SUCCESS = "GetAllProducts_SUCCESS";
export const GetAllProducts_FAIL = "GetAllProducts_FAIL";

